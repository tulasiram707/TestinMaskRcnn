import pandas as pd
import numpy as np

spoon_df=pd.read_json("via_region_data.json")
spoon_df=spoon_df.transpose()[['filename','regions']].reset_index()
print(spoon_df)

print(spoon_df["regions"][0][0]["shape_attributes"])

data_list = []
for row in range(spoon_df.shape[0]):
    data = spoon_df['regions'][row][0]['shape_attributes']
    data_list.append(data)
datadf = pd.DataFrame(data_list)
#spoon_df = pd.concat([spoon_df,datadf],1)[['filename','height','width','x','y']]

print(datadf)